<!DOCTYPE html>
<html>
<head>
   <title>SUBJECT INSPECTION REPORT</title>
   <style type="text/css">
    #table-border {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#table-border td, #table-border th {
    border: solid 1px #ddd !important;
    padding: 8px;
}

#table-border tr:nth-child(even){background-color: #f2f2f2;}

#table-border tr:hover {background-color: #ddd;}

#table-border th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
   </style>
</head>
<body>
  <div><p><img  style="height:110px; width:110px; padding-left: 270px;" src="{{ public_path().'/images\logo.png' }} " /></p>
        <br></div>
	<div style="padding-top: -50px;">     
		<p><center>HURUMA INVESTMENT IMPORT & EXPORT COMPANY LTD</center></p>
		<p><center>AMANI- MAGOGONI</center></p>
		<p><center>P. O. BOX 1568  ZANZIBAR</center></p>
        <p><center>TEL: +(255) 24 223 4163</center></p>
        <p><center>Mobile: +(255) 777 470 883, + (255) 652 084 994</center></p>
        <p><center>E-mail : kimenya@yahoo.com</center></p>
	</div>
    <hr>
	<div>
        <p>{!! $letter->description !!}</p>
    </div>
    <div>
        <p><center>Dr. Kassim</center></p>
        <p><center>Head officer</center></p>
    </div>
    
    </script>
</body>
</html>