<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                       
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-book"></i> GreenLand Management<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('new-greenland-invoice')); ?>"><i class="fa fa-plus"></i> Create Invoice</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('greenland-invoices')); ?>"><i class="fa fa-list"></i> List Invoice</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-book"></i> Al-Amin Management<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('new-al-amin-invoice')); ?>"><i class="fa fa-plus"></i> Create Invoice</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('al-amin-invoices')); ?>"><i class="fa fa-list"></i> List Invoice</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-book"></i> Meridian Management<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo e(route('new-meridian-invoice')); ?>"><i class="fa fa-plus"></i> Create Invoice</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('meridian-invoices')); ?>"><i class="fa fa-list"></i> List Invoice</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav><?php /**PATH /home4/greenbar/inv.greenlandzanzibar.com/resources/views/inc/leftbar.blade.php ENDPATH**/ ?>