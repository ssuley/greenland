

<?php $__env->startSection('css'); ?>
    <style> #disable-calender { pointer-events: none; } </style>
    <link href="<?php echo e(asset('dist/css/style.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scriptTop'); ?>
<script src="<?php echo e(asset('js/tinymce.min.js')); ?>"></script>

  <script>tinymce.init({selector:'textarea'});</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                <div class="col-lg-12">
                    <h1 class="page-header"><h2 class="title">Create Letter</h2></h1>
                    <div class="panel">

<div class="panel-body">   
    <div class="content-letter">
    <form action="<?php echo e(route('insert-rate')); ?>" id="invoice-form" method="post" class="invoice-form" role="form" novalidate=""> 
        <div class="load-animate animated fadeInUp">
             <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <div class="row">
                            
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                   <div class="form-group">
                        <input type="text" name="rate" class="form-control <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"> 
                         <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <span class="invalid-feedback text-danger" role="alert">
                        <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
                </div>
            </div>

            <div class="clearfix"></div> 
                 <div class="form-group">
                            <div class="input-group">
                                <input type="submit" class="form-control" name="submit" value="Save & Print" class="btn btn-success btn-lg">
                            </div>
                        </div>           
        </div>
    </form>        
    </div>                              
                                               
                                            </div>
                                        </div>
                </div>
                
          

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/greenbar/inv.greenlandzanzibar.com/resources/views/rate/create.blade.php ENDPATH**/ ?>