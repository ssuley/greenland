    
    <?php $__env->startSection('css'); ?>
    <!-- DataTables CSS -->
    <link href="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.css')); ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('vendor/datatables-responsive/dataTables.responsive.css')); ?>" rel="stylesheet">
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
                <div class="col-lg-12">
                <h1 class="page-header">Invoice List</h1>
            </div>
            <div class="row">
                <div class="col-lg-12">
                <div class="panel panel-default">
                <div class="panel-heading">
                DataTables Advanced Tables
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                        <tr>
                            <th>Invoice No.</th>
                            <th>Created Date</th>
                            <th>Customer Name</th>
                            <th>Proforma Invoice</th>
                            <th>Schedule Price</th>
                            <th>Tax Invoice</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $count=1; ?>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                    <td><?php echo e($count++); ?></td>
                    <td><?php echo e($invoice->created_at); ?></td>
                    <td><?php echo e($invoice->companyName); ?></td>

                    <td><a href="<?php echo e(route('alamin-invoice-pdf',$invoice->invoice_id)); ?>" title="Al-Amin Invoice"><i class="glyphicon glyphicon-print"></i></a>
                    </td>

                    <td><a href="<?php echo e(route('alamin-schedule-pdf',$invoice->invoice_id)); ?>" title="Al-Amin Invoice"><i class="glyphicon glyphicon-print"></i></a>
                    </td>

                    <td><a href="<?php echo e(route('alamin-tax-pdf',$invoice->invoice_id)); ?>" title="Al-Amin Invoice"><i class="glyphicon glyphicon-print"></i></a>
                    <td>
                    <a href="<?php echo e(route('edit-al-amin-invoice',$invoice->invoice_id)); ?>"><i class="fa fa-edit"></i></a>
                    <form action="<?php echo e(route('delete-al-amin-invoice',$invoice->invoice_id)); ?>" method="post" class="pull-right">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" style="border: none;" onclick="Javasrcrip:return window.confirm('Are you sure! You want to delete ')" class=" waves-light " title="delete">
                    <i class="fa fa-trash-o text-danger"></i>
                    </button>
                    </form>
                    </td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <!-- /.table-responsive -->

                </div>
                <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>

    <!-- DataTables JavaScript -->
    <script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datatables-responsive/dataTables.responsive.js')); ?>"></script>
    <script>
    $(document).ready(function() {
    $('#dataTables-example').DataTable({
    responsive: true
    });
    });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/greenbar/inv.greenlandzanzibar.com/resources/views/alamin/index.blade.php ENDPATH**/ ?>